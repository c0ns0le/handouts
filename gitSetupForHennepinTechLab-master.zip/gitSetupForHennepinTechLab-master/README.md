# gitSetupForHennepinTechLab
instructions for setting up git on the lab computer in H155
at Hennepin Technical College
